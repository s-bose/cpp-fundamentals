#include "noentry.ih"

size_t NoEntry::area() const
{
    return d_area;
}
