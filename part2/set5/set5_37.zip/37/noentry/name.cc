#include "noentry.ih"

string const &NoEntry::name() const
{
    return d_name;
}
