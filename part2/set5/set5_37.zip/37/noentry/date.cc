#include "noentry.ih"

size_t NoEntry::date() const
{
    return d_date;
}
