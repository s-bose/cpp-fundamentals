#include <iostream>
#include "noentry/noentry.h"
#include "privilegedone/privilegedone.h"


int main()
{}