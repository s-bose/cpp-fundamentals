#include "lines.ih"

    // initialize the global VecMap object
map<Lines const *, vector<string>> VecMap;
