#include "base.ih"

Base::~Base()
{}