#include "maxfour.ih"

size_t MaxFour::d_count = 0;