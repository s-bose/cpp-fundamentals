#include "maxfour.ih"

size_t MaxFour::count()
{
    return d_count;
}
