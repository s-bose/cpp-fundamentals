#include "funcTemplate.h"

Impl1::Impl1()
{
    FUNCPTR = total; // instantiate total for int
}                    // by taking its address