#include "funcTemplate.h"

Impl2::Impl2()
{
    FUNCPTR = total;
}