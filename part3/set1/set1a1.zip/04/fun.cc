#include "main.ih"

void fun(int first, int second)
{
    cout << "fun() called with args: " 
         << first << ", " << second << '\n';
}