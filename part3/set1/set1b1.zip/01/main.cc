#include "main.ih"

int main()
{
    fun1();
    fun2();
}