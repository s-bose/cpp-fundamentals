#include <iostream>

int main()
{
    std::cout << "Hello World" << '\n';  // prints "Hello World"
}
