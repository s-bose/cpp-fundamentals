#ifndef INCLUDED_SUMS_
#define INCLUDED_SUMS_

                            // take total as a reference from the caller
void sum(int argc, char *argv[], int &total); 
void sum(int argc, char *argv[], double &total); 

#endif
