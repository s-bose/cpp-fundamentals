#include "copycat.ih"

char const *const *const CopyCat::data() const
{
    return d_data;
}